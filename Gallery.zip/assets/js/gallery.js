const menuItems = [
    {
        cate: 'ALL',
        icon: './assets/images/icon-1.svg',
    },
    {
        cate: 'Kitchen',
        icon: './assets/images/icon-2.svg',
    },
    {
        cate: 'Living Room',
        icon: './assets/images/icon-3.svg',
    },
    {
        cate: 'Bathroom',
        icon: './assets/images/icon-4.svg',
    },
    {
        cate: 'Bedroom',
        icon: './assets/images/icon-5.svg',
    },
    {
        cate: 'Ceramic',
        icon: './assets/images/icon-5.svg',
    },
]

let galleryItems = [
    {
        pic: './assets/images/pic-1.jpg',
        name: 'Veneer lamellar structure 1',
        link: '#',
        cate: 'Kitchen'
    },
    {
        pic: './assets/images/pic-2.jpg',
        name: 'Veneer lamellar structure 2',
        link: '#',
        cate: 'Living Room',
    },
    {
        pic: './assets/images/pic-3.jpg',
        name: 'Veneer lamellar structure 3',
        link: '#',
        cate: 'Bathroom',

    },
    {
        pic: './assets/images/pic-4.jpg',
        name: 'Veneer lamellar structure 4',
        link: '#',
        cate: 'Bedroom',
    },
    {
        pic: './assets/images/pic-5.jpg',
        name: 'Veneer lamellar structure 5',
        cate: 'Ceramic',
        link: '#',
    },
    {
        pic: './assets/images/pic-6.jpg',
        name: 'Veneer lamellar structure 6',
        cate: 'Living Room',
        link: '#',
    },
    {
        pic: './assets/images/pic-7.jpg',
        name: 'Veneer lamellar structure 6',
        cate: 'Living Room',
        link: '#',
    },
    {
        pic: './assets/images/pic-8.jpg',
        name: 'Veneer lamellar structure 6',
        cate: 'Living Room',
        link: '#',
    },
    {
        pic: './assets/images/pic-9.jpg',
        name: 'Veneer lamellar structure 6',
        cate: 'Living Room',
        link: '#',
    },
];

function renderGallery (listData){
    const gallery = document.getElementById('gallery')

    const eleGalllery = listData.reduce((eleMerge,itemCurrent) => {
        eleMerge += `<div class="brandcate_dls_1_0_0__item">
            <a href="#">
                <img
                    src="${itemCurrent.pic}" alt="${itemCurrent.name}">
                    </a>
        </div> `
        return eleMerge
    },'')

    if(gallery)
        gallery.innerHTML = eleGalllery;
    
}


function removeClassActiveItemMenu(){
    const menuEle = document.getElementById('menu-filter');
    for(let i of menuEle.children){
        i.removeAttribute('class')
    }
}

function cateFilter (cateFilter,thisEle){
    removeClassActiveItemMenu()
    thisEle.classList.add('active')
    const imagesFilter = cateFilter === 'ALL' ? galleryItems : galleryItems.filter(i => i.cate === cateFilter)
    renderGallery(imagesFilter)
}


function renderMenu() {

    const menuEle = document.getElementById('menu-filter');
    let eleRender = '';

    menuItems.forEach((i,index) => {
        eleRender = eleRender + `
            <li class="" onclick="cateFilter('${i.cate}',this)">
                <img src="${i.icon}" alt="${i.cate}">
                <p>${i.cate}</p>
            </li>
        `
    })
    if(menuEle)
        menuEle.insertAdjacentHTML('beforeend', eleRender);
}

renderGallery(galleryItems);
renderMenu();